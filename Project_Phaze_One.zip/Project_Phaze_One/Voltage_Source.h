//
// Created by amirh on 2025-05-23.
//

#ifndef PROJECT_PHAZE_ONE_VOLTAGE_SOURCE_H
#define PROJECT_PHAZE_ONE_VOLTAGE_SOURCE_H


class Voltage_Source
{
public:

};


#endif //PROJECT_PHAZE_ONE_VOLTAGE_SOURCE_H
